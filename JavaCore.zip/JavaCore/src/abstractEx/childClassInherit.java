package abstractEx;

public class childClassInherit extends parentClassInherit {

	
	public void engine() {
		System.out.println("new engine");
	}
	public void color() {
		System.out.println(color);
	}
	public static void main(String[] args) {
	
		childClassInherit cci = new childClassInherit();
		
		cci.color();

	}

}
