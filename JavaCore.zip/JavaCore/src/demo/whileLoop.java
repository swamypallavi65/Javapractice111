package demo;

public class whileLoop {
	
	public static void main(String[] args) {
	int i=10;
	
	while(i>0) {
		System.out.println(i);
		i--;// if we don't provide then it will run infinite loop
	}
	}

}
