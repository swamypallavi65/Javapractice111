package demo;

public class revDemo {

	public static void main(String[] args) {
		
		String a ="madam";
		String t="";
		
		for(int i= a.length() - 1; i >=0; i--) {
			t=t+a.charAt(i);
		}
			System.out.println("reversed string:" + t);
			
			if(a.equals(t)) {
				System.out.println("string is palindrom");
			}
			else {
				System.out.println("string is not palindrom");
			}
		}

	

}