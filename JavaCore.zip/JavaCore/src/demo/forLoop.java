package demo;

public class forLoop {

	
	public static void main(String[] args) {
	
		if(5>2) {
			System.out.println("sucess");
		}
		else {
			System.out.println("fail");
		}
		for(int i=0;i<10;i=i+2) {
			System.out.println(i);
		}
	}

}
