package demo;

public class test1 {

	static int a=4;
	public void getData(){
		System.out.println("I'm in method");
		
	}
	public static void main(String[] args) {
		
		//creating object so we can access any methods within this class
		test1 fn = new test1();
		test2 fn2 = new test2();
		fn.getData();
		fn2.setData();
		System.out.println(a);
		System.out.println("hello world");

	}

}
