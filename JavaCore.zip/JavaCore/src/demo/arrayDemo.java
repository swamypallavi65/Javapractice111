package demo;

public class arrayDemo {

	public static void main(String[] args) {
	
		int a[] = new int[5];// declares an array and allocates memory for the variable
		a[0]=2;
		a[1]=21;
		a[2]=12;
		a[3]=4;
		a[4]=8;
		
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);//retrieve the values present in the array
		}

	}

}
