package demo_selenium;


			import org.openqa.selenium.By;
			import org.openqa.selenium.WebDriver;
			import org.openqa.selenium.WebElement;
			import org.openqa.selenium.chrome.ChromeDriver;
			import java.time.Duration;
			import java.util.List;

		public class test2 {

		    public static void main(String[] args) {
		        WebDriver driver = new ChromeDriver();
		        String url = "https://www.bing.com";

		        try {
		            driver.get(url);
		            driver.manage().window().maximize();

		          
		            Thread.sleep(2000);

		            // Find all <a> tags (links)
		            List<WebElement> links = driver.findElements(By.tagName("a"));
		            System.out.println("Total links found: " + links.size());

		            // Traverse and print link texts
		            for (WebElement link : links) {
		                String text = link.getText().trim();
		                if (!text.isEmpty()) {
		                    System.out.println("Link Text: " + text);
		                }
		            }

		        } catch (Exception e) {
		            e.printStackTrace();
		        } finally {
		            driver.quit();
		        }
		    }
		}



