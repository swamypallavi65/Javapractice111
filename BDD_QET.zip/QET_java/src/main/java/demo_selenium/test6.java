package demo_selenium;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class test6 {
	
	WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		
	WebDriver driver = new ChromeDriver();
	String url = "http://practice.automationtesting.in/";

	try {
		driver.get(url);
		driver.manage().window().maximize();
		// shop
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	//	driver.findElement(By.linkText("Shop")).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Shop"))).click();

	// menu
	//	driver.findElement(By.linkText("Home")).click();
		
	
		WebElement menuBtn = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Home")));
		menuBtn.click();
	
	// 3 slide
		//List<WebElement> sliders = driver.findElements(By.className("//*[contains(@class='n2-ss-slide-background')]"));
		List<WebElement> sliders = driver.findElements(By.className("n2-ss-slide-background"));
		int slideCount = sliders.size();
		if(slideCount == 3) {
			System.out.println("Pass:Home page having 3 slide");
		}
		else {
			System.out.println("Fail:Home page is not having 3 slide:"+slideCount);
		}
		
	}
	finally{
		driver.quit();
		
	}

}
}