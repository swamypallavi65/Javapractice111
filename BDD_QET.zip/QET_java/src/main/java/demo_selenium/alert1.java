package demo_selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class alert1 {

	 static WebDriver driver ;
	public static void main(String[] args) throws InterruptedException {
	
	    driver = new ChromeDriver();
       String url = "https://demo.automationtesting.in/Alerts.html";

           driver.get(url);
           driver.manage().window().maximize();
           Thread.sleep(1000);
//           
//           WebElement elem1 = driver.findElement(By.xpath("//*[@id='OKTab']//*[@class='btn btn-danger']"));
//           elem1.click();
//           System.out.println("alert message:"+elem1.getText());
           
           WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
           WebElement elem1  = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='OKTab']//*[@class='btn btn-danger']")));
           elem1.click();
          
           String alertText = driver.switchTo().alert().getText();
           System.out.println("alert message: " + alertText);
//alert using accept/dismiss method 
           
           driver.switchTo().alert().accept();
           System.out.println("clicked on ok");
           
           //next button Alert with OK and Cancel
           driver.findElement(By.xpath("//*[@href='#CancelTab'][text()='Alert with OK & Cancel ']")).click();
           
           WebElement elem2  = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='CancelTab']//*[@class='btn btn-primary']")));
           elem2.click();
           
           String alertText1 = driver.switchTo().alert().getText();
           System.out.println("alert with Ok and cancel message: " + alertText1);
           //alert using accept/dismiss method 
           
           driver.switchTo().alert().accept();
           System.out.println("Alert with OK and Cancel");
           
           
         

	}

}
