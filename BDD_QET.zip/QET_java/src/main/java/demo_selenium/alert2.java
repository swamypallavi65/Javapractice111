package demo_selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class alert2 {

	 static WebDriver driver ;
	public static void main(String[] args) throws InterruptedException {
	
	    driver = new ChromeDriver();
	    String url = "https://demoqa.com/buttons";

          driver.get(url);
          driver.manage().window().maximize();
          Thread.sleep(1000);
          
       // Scroll to vertically

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(0, 300);");

          //double click
          WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
          WebElement elm1 = driver.findElement(By.id("doubleClickBtn"));
          Actions action = new Actions(driver);
          action.doubleClick(elm1).perform();
          System.out.println("Double click message:" +elm1.getText());
          
          //Right click 
          
          WebElement elm2 = driver.findElement(By.id("rightClickBtn"));
          action.contextClick(elm2).perform();
          System.out.println("Right click message:" +elm2.getText());
          
          //click me
        
          WebElement elm3 = driver.findElement(By.xpath("//*[@class='btn btn-primary'][text()='Click Me']"));
         // action.click(elm3);
          action.doubleClick(elm3).perform();
          System.out.println("Click Me mesaage:" +elm3.getText());
	}

}
