package com.cg.assign1;

import java.awt.print.Book;

public class main {

	public static void main(String[] args) {
	
		author author1 = new author("pallavi");
		
		author author2 = new author("pallavi1");
		author author3 = new author("pallavi2");
		
		book book1 = new book(1, "CG_story", 10, "CG");
		book book2 = new book(2, "CG_story1", 11, "CG1");
		book book3 = new book(3, "CG_story2", 12, "CG2");
		
		bookCount(book1);
		bookCount(book2);
		bookCount(book3);
		
		System.out.println("Total count of books: 3");
	}

	private static void bookCount(book book) {
		System.out.println("bookid:"+book.getBookid());
		System.out.println("bookname:"+book.getBookname());
		System.out.println("bookprice: $"+book.getBookprice());
		System.out.println("author:"+book.getAuthor());
		
		
	}

}
