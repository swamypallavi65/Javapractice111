package com.cg.assign1;

public class author {
	
	private String authorName;

	public author(String authorName) {
		super();
		this.authorName = authorName;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	
	


}
