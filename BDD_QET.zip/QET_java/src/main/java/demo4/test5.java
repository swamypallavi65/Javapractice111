package demo4;

public class test5 {

	public static void main(String[] args) {
	
		//a[row][column]
//		int a[][]= new int[3][3];
//		a[0][0]=0;
//		a[0][1]=1;
//		a[0][2]=4;
//		a[1][0]=7;
//		a[1][1]=8;
//		a[1][2]=2;
//		a[2][0]=7;
//		a[2][1]=8;
//		a[2][2]=2;
		//System.out.println(a[0][2]);
//		int a[][]= {{2,4,5},{3,4,7},{5,2,1}};
//		int b[][]= {{2,4,5},{3,4,7},{5,2,1}};
//		for(int i=0;i<3;i++) {
//			for(int j=0;j<3;j++) {
//				System.out.println(a[i][j]);
//				System.out.println(b[i][j]);
		int[][] mulArr = {
				{1, 2, 3},
				{4, 5, 6},
				{7, 8, 9}
				};
		
		for(int i=0;i<mulArr.length;i++) {
			for(int j=0;j<mulArr[i].length;j++) {
//				System.out.println(a[i][j]);
//				System.out.println(b[i][j]);
				System.out.println(mulArr[i][j]+"");
			}
		}

	}
}


