package demo4;

import java.util.Scanner;

public class test3 {

	public static void main(String[] args) {
	
		System.out.println("Add number of row");
		Scanner sc = new Scanner(System.in);
	
		int row = sc.nextInt();
		int num = 1;
		
		while(num <= row) {
		for(int i=1;i<=num;i++) {
			System.out.print("*");
		}
		System.out.println();
		num++;

	}
	}
}
