package demo4;

public class test4 {

	public static void main(String[] args) {
		
		if(5>2) {
			System.out.println("pass");
		}
		else {
		System.out.println("fail");
	}

	for(int i=0;i<10;i=i+2) {
		System.out.println(i);
	}
	
	
//=======	
	int j=20;
	do {
		System.out.println(j);
		j++;
	}while(j>30);//only 1 loop execution is possible this way with do while
	
	


	//===============
	int k = 1;
	while(k <= 5) {

		 System.out.println("Number: " + k);
		            k++;
	}
	}
}



