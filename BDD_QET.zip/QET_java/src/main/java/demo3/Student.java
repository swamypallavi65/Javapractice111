package demo3;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Student {

	public static void main(String[] args) {
		
		
		HashMap<Integer, String> stud = new HashMap<Integer, String>();
		stud.put(100, "Pallavi");
		stud.put(101, "Pallavi1");
		stud.put(104, "Bob");
		stud.put(108, "Dev");
		stud.put(102, "Pallavi2");
		
		for(Map.Entry<Integer, String> entry: stud.entrySet()) {
			System.out.println(" roll num :" +entry.getKey()+"| name :" +entry.getValue());
		}
	    // Search Roll number exists, update name
		int rollNoToCheck = 102;
        String newName = "Sneha";

        // Check and update
        if (stud.containsKey(rollNoToCheck)) {
        
            stud.put(rollNoToCheck, newName);
            System.out.println("Updated: Roll No " + rollNoToCheck);
        } else {
           
            stud.put(rollNoToCheck, newName);
            System.out.println("Added: Roll No " + rollNoToCheck);
        }

        System.out.println("\nAll Students:");
         for (Integer roll : stud.keySet()) {
             System.out.println("Roll No: " + roll + ", Name: " + stud.get(roll));
         }
         
         TreeMap<Integer, String> sortRoll = new TreeMap<>(stud);
         System.out.println("sort roll num");
         
         for(Map.Entry<Integer, String> entry : sortRoll.entrySet()){
        	 System.out.println(" roll num :" +entry.getKey()+"| name :" +entry.getValue());
         }

	}

}
