package demo1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//Add Products in Cart
public class test12 {
	
	public static WebDriver driver;
	public static WebElement element;

	public static void main(String[] args) throws InterruptedException {
		
		 driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();

		boolean logo = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();

		if(logo==true)
		{
		System.out.println("Home page is displayed");
		}
		else{
		System.out.println("Home page is not displayed");
	}
		// cart
		driver.findElement(By.xpath("//*[@href='/products'][text()=' Products']")).click();
		//add to cart
		
		driver.findElement(By.xpath("//*[@class=\"brands_products\"]")).isDisplayed();
		driver.findElement(By.xpath("//*[@href='/product_details/1'][text()='View Product']")).click();		
 
		driver.findElement(By.xpath("//*[@class='btn btn-default cart']")).click();
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		WebElement viewcart = wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[text()='View Cart']"))));
		viewcart.click();
		WebElement checkOutpg = driver.findElement(By.xpath("//*[@class=\"active\"]"));
		System.out.println("check out page display:"+checkOutpg.getText());
		//check out
		driver.findElement(By.xpath("//*[@class=\"btn btn-default check_out\"]")).click();
	}
}
