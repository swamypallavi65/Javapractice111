package demo1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class test9 {
	

	public static WebDriver driver;
	public static WebElement element;

	public static void main(String[] args) throws InterruptedException {
		
		 driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();

		boolean logo = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();

		if(logo==true)
		{
		System.out.println("Home page is displayed");
		}
		else{
		System.out.println("Home page is not displayed");
	}
		driver.findElement(By.xpath("//*[@href='/products'][text()=' Products']")).click();
		boolean prod = driver.findElement(By.xpath("//*[@class='title text-center'][text()='All Products']")).isDisplayed();

		if(prod==true)
		{
		System.out.println("Product page is displayed");
		}
		else{
		System.out.println("product page is not displayed");
	}
		driver.findElement(By.id("search_product")).sendKeys("Blue Top");
		
		driver.findElement(By.id("submit_search")).click();
		
		JavascriptExecutor j = (JavascriptExecutor) driver;
		//To scroll down
		j.executeScript("window.scrollBy(0,500)");
		
		

		boolean searchPrd = driver.findElement(By.xpath("//h2[@class='title text-center'][text()='Searched Products']")).isDisplayed();
					if(logo==true)
				{
					System.out.println("Searched product page is displayed");
					}
					else{
					System.out.println("Searched product page is not displayed");
				}
					
					List<WebElement> products = driver.findElements(By.xpath("//div[@class='features_items']//div[@class='product-image-wrapper']"));
					if (products.size() > 0) {
					    System.out.println("Products related to search are visible. Total: " + products.size());
					    for (WebElement product : products) {
					        System.out.println("Product: " + product.getText());
					    }
					} else {
					    System.out.println("No products found related to search.");
					}

}
}
