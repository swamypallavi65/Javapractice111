package demo1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class test2_correctemail_pswd {
	public static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {
		//Login User with correct email and password
		 driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		boolean logo = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[1]/div/a/img")).isDisplayed();
		if(logo==true)
		{
		System.out.println("Home page is displayed");
		}
		else{
		System.out.println("Home page is not displayed");
	}
	

	WebElement newUser_Signup =driver.findElement(By.xpath("//*[@href='/login'][text()=' Signup / Login']"));

	newUser_Signup.click();
	//login to your account verify
	//*[text()='Login to your account']
	boolean loginAc = driver.findElement(By.xpath("//*[text()='Login to your account']")).isDisplayed();
	if(loginAc=true) {
		System.out.println("Login to your account displayed");
	}
	else {
		System.out.println("Login to your account not displayed");
	}
	//Enter user cred
	driver.findElement(By.xpath("//*[@data-qa='login-email']")).sendKeys("abc7abc@gmail.com");
	driver.findElement(By.name("password")).sendKeys("abcabc@123");
	driver.findElement(By.xpath("//*[@data-qa='login-button'][text()='Login']")).click();
	//verify logged user 
	//boolean loginUser = driver.findElement(By.xpath("//*[text()=' Logged in as ']//parent::a")).isDisplayed();
	boolean loginUser = driver.findElement(By.xpath("//*[text()=' Logged in as ']//parent::a")).isDisplayed();
	
	if(loginUser=true) {
		System.out.println("Username is visible");
	}
	else {
		System.out.println("Username is not visible");
	}
	WebElement loginUser1 = driver.findElement(By.xpath("//*[text()=' Logged in as ']//parent::a"));
	System.out.println("username"+loginUser1.getText());
	}
}
