package demo1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//Verify Test Cases Page
public class test7 {
	
	public static WebDriver driver;
	public static WebElement element;

	public static void main(String[] args) throws InterruptedException {
		
		 driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();

		boolean logo = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();

		if(logo==true)
		{
		System.out.println("Home page is displayed");
		}
		else{
		System.out.println("Home page is not displayed");
	}
		driver.findElement(By.xpath("//*[@href='/test_cases'][text()=' Test Cases']")).click();
		boolean Testcase = driver.findElement(By.xpath("//*[@class='title text-center']//*[text()='Test Cases']")).isDisplayed();

		if(Testcase==true)
		{
		System.out.println("Testcase page is displayed");
		}
		else{
		System.out.println("Testcase  page is not displayed");
	}
		WebElement testCase = driver.findElement(By.xpath("//*[@class='title text-center']//*[text()='Test Cases']"));
		System.out.println("testcase text:"+testCase.getText());
		
		driver.quit();
	}
}
