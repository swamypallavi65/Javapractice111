package demo1;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


//Contact Us Form
public class Test6 {
	
	public static WebDriver driver;
	public static WebElement element;

	public static void main(String[] args) throws InterruptedException {
		
		 driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();

		boolean logo = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();

		if(logo==true)
		{
		System.out.println("Home page is displayed");
		}
		else{
		System.out.println("Home page is not displayed");
	}
		//contact us
		 driver.findElement(By.xpath("//*[@href='/contact_us']")).click();
		System.out.println("contactus:");
			//enter user details
			
			WebElement getTouch = driver.findElement(By.xpath("//h2[@class='title text-center'][text()='Get In Touch']"));
			getTouch.click();
			System.out.println("getTouch:"+getTouch.getText());
			
			Map<String, String> contactFm = new HashMap();
			contactFm.put("name", "Pallavi");
			contactFm.put("email", "abc7@gmail.com");
			contactFm.put("subject", "contact automation practice");
			contactFm.put("message", "Java Automation Testing");
			for(Map.Entry<String, String> entry: contactFm.entrySet()) {
				try {
					WebElement data = driver.findElement(By.name(entry.getKey()));
					data.clear();
					data.sendKeys(entry.getValue());
				}catch(Exception e) {
					System.out.println("data not found: " +entry.getKey());
				}
			}
			//file upload
			WebElement uploadFile =driver.findElement(By.name("upload_file"));
			//element.click();
			uploadFile.sendKeys("C:\\Users\\p300\\OneDrive - Capgemini\\Documents\\testAuto.txt");
		
			driver.findElement(By.name("submit")).click();
			driver.switchTo().alert().accept();
			
			
			
			WebElement detailsSub = driver.findElement(By.xpath("//*[text()='Success! Your details have been submitted successfully.']"));
			System.out.println("user details submission message"+detailsSub.getText());
			driver.findElement(By.xpath("//*[@class='fa fa-home']")).click();
			logo = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();

			if(logo==true)
			{
			System.out.println("Home page is displayed");
			}
			else{
			System.out.println("Home page is not displayed");
		}
			driver.quit();
		
	}

}
