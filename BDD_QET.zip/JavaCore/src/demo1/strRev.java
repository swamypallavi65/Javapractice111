package demo1;

public class strRev {

	public static void main(String[] args) {
		
		
		String input ="Hello World";
		String rev = "";
		
		for(int i=input.length()-1;i >=0;i--) {
			rev=rev+input.charAt(i);
			
			
		}
		System.out.println("input:"+input);
		System.out.println("rev:"+rev);
		

	}

}
