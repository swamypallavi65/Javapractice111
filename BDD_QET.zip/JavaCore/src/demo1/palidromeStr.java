package demo1;

public class palidromeStr {
	
	public static void main(String[] args) {
	String s = "madam";
	String t="";
	
	for(int i=s.length()-1;i>=0;i--) {
		
	//	System.out.println(s.charAt(i)); //without below line it can print output of string madam
		t=t+s.charAt(i);
	}
	System.out.println(t);
//	if(s==t) {
//		System.out.println("String is palindrome");
//	}
//	else {
//		System.out.println("String is not palindrome");
//	}
	}
	
}
