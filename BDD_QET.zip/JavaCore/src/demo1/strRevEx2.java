package demo1;

public class strRevEx2 {

	public static void main(String[] args) {
		String origional ="Hi,How are you?";
		String reverse=reverseStr(origional);
		
		System.out.println("origional:"+origional);
		System.out.println("reverse:"+reverse);
	}
	public static String reverseStr(String str) {
		
		String revStr = "";
		for(int i=str.length()-1;i >=0;i--) {
			revStr = revStr+str.charAt(i);
		}
		
		return revStr;
		
	}
}
