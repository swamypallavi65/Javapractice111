package demo1;

public class strRevBuild {

	public static void main(String[] args) {
		
		String origional ="Hello World";
		String reverse = reverseStr(origional);
		
		System.out.println("origional:"+origional);
		System.out.println("reverse:"+reverse);

	}

	private static String reverseStr(String str) {
		
		StringBuilder sb = new StringBuilder(str);
		return sb.reverse().toString();
		
		
	}

}
