package abstractEx;

public class childClass extends ParentAircraft {
	
	public static void main(String[] args) {
		
		childClass cc = new childClass();
		cc.bodyColor();
		cc.safety();
		cc.engine();
	}

	@Override
	public void bodyColor() {
	
		System.out.println("body color");
		
	}

}
