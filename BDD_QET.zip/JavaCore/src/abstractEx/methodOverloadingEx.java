package abstractEx;

//function overloading
//either argument count should be different or argument data type should be different
public class methodOverloadingEx extends childClassInherit {
	
	public void getData(int a) {
		System.out.println(a);
		
	}
	public void getData(String a) {
		System.out.println(a);
	}
	public static void main(String[] args) {
		
		methodOverloadingEx moe = new methodOverloadingEx();
		moe.audioSystem();
		moe.getData(4);
		moe.getData("hello");
	}
	

}
