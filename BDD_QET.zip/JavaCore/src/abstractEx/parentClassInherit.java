package abstractEx;

public class parentClassInherit {

	String color = "red";
	
	public void gear() {
		System.out.println("gear code implemented");
	}
	
	public void brakes() {
		System.out.println("brakes code implemented");
	}
	
	public void audioSystem() {
		System.out.println("audio system code implemented");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
