package abstractEx;

public abstract class ParentAircraft {

	//non abstract method
	
	public void engine() {
		
		System.out.println("Follow engine guidelines");
	}
	public void safety() {
		
		System.out.println("Follow safety guidelines");
		
	}
	
	public abstract void bodyColor();
	
	

}
