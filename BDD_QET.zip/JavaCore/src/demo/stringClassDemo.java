package demo;

public class stringClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//string: It's one of the pre built class in java
		//String is literal by creating an object 
		String a="  javatraInIng"; // string literal
		String b = new String("javasdettraining");// string class method
		
		System.out.println(a);
		System.out.println(a.charAt(0));
		System.out.println(a.substring(1));
		System.out.println(a.substring(3, 5));
		System.out.println(a.concat("sdet"));
		//trim
		System.out.println(a.trim());
		System.out.println(a.toUpperCase());
		System.out.println(a.toLowerCase());
		//split
		String c[]=a.split("t");
		System.out.println(c[0]);// Splitting string a char in two index
		System.out.println(c[1]);
		System.out.println(a.replace("t", "v"));

	}

}
