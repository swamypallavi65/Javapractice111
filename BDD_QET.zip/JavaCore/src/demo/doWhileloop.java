package demo;

public class doWhileloop {

	public static void main(String[] args) {
		
		
		int j=20;
		do {
			System.out.println(j);
			j++;
		}while(j>30);//only 1 loop execution is possible this way with do while
		

	}

}
