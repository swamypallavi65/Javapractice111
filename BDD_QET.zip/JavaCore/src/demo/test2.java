package demo;

public class test2 {
	
	public void setData(){
		
		System.out.println("I'm in second method");
	}

}
