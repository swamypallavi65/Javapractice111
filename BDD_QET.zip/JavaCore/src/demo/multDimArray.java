package demo;

public class multDimArray {

	public static void main(String[] args) {
		//a[row][column]
		int a[][]= new int[2][3];
		a[0][0]=0;
		a[0][1]=1;
		a[0][2]=4;
		a[1][0]=7;
		a[1][1]=8;
		a[1][2]=2;
		//System.out.println(a[0][2]);
		
		int b[][]= {{2,4,5},{3,4,7},{5,2,1}};
		
		for(int i=0;i<2;i++) {
			for(int j=0;j<3;j++) {
				System.out.println(a[i][j]);
				System.out.println(b[i][j]);
			}
		}

	}

}
