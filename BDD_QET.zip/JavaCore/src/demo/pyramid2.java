package demo;

public class pyramid2 {

	public static void main(String[] args) {
		int k=1;
		for(int i=0;i<5;i++) {
		//	System.out.println("outter loop started");
			for(int j=0;j<=i;j++) {
				System.out.print( k);//in one line
				System.out.print("\t");// help in spacing
				k++;
			}
			System.out.println( "");// print next line
		}

	}

}
