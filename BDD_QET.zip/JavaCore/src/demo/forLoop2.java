package demo;

public class forLoop2 {

	public static void main(String[] args) {
		
		for(int i=5;i<3;i++) {
			System.out.println(i);
		}

	}

}
