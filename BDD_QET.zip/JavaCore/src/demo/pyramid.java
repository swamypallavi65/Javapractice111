package demo;

public class pyramid {

	public static void main(String[] args) {
		int k=1;
		for(int i=0;i<4;i++) {
		//	System.out.println("outter loop started");
			for(int j=0;j<4-i;j++) {
				System.out.print( k);//in one line
				System.out.print("\t");// help in spacing
				k++;
			}
			System.out.println( "");// print next line
		}

	}

}
