package demo;

public class loopEx2 {

	public static void main(String[] args) {
		
		for(int i=0;i<=4;i++) {
			System.out.println("outter loop started");
			for(int j=0;j<=5;j++) {
				System.out.println("inner loop started");
			}
			System.out.println("outter loop finished");
		}

	}

}
