package demoInterface;

public class IndTraffic implements CentralTraffic,ContinentalTraffic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//implementing the centraltraffic details by creating object
		CentralTraffic a = new IndTraffic();
		a.redStop();
		a.yellowReady();
		a.greenGo();
		IndTraffic at = new IndTraffic();
		ContinentalTraffic ct = new IndTraffic();
		at.walkSymbol();
		
	}

	@Override
	public void redStop() {
		// TODO Auto-generated method stub
		System.out.println("red stop");
	}

	@Override
	public void yellowReady() {
		// TODO Auto-generated method stub
		System.out.println("yellow ready");
	}

	@Override
	public void greenGo() {
		// TODO Auto-generated method stub
		System.out.println("green  go");
		
	}

	public void walkSymbol() {
		System.out.println("walk symbol");
	}
}
