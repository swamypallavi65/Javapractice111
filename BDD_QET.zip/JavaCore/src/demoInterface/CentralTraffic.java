package demoInterface;

public interface CentralTraffic {
	
	public void redStop();
	public void yellowReady();
	public void greenGo();
	

}
