package demoInterface;

public interface ContinentalTraffic {

}
