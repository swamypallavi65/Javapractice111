package day4;

import java.util.Stack;

public class StackDemo {
	
	private Stack<String> backHistory;
	private Stack<String> forwardHistory;
	private String currentPage;
	
	public void setUp()
	{
		backHistory=new Stack<>();
		forwardHistory=new Stack<>();
		currentPage=null;
	}
	
	
	public void visit(String url)
	{
		if(currentPage!=null)
		{
			backHistory.add(currentPage);
			forwardHistory.clear();
		}
		currentPage=url;
		System.out.println("Visited "+url);
	}
	
	
	public void back()
	{
		if(!backHistory.isEmpty())
		{
			forwardHistory.add(currentPage);
			currentPage=backHistory.pop();
			System.out.println("Back :"+currentPage);
		}
		else
			System.out.println("Backward history is empty");
		
	}
	
	public void forward()
	{
		if(!forwardHistory.isEmpty())
		{
			backHistory.add(currentPage);
			currentPage=forwardHistory.pop();
			System.out.println("Forward :"+currentPage);
		}
		else
			System.out.println("Forward history is empty");
		
	}
	
	public static void main(String[] args)
	{
		StackDemo navigate=new StackDemo();
		navigate.setUp();
		
		navigate.visit("example1.com");
		navigate.visit("example2.com");
		navigate.visit("example3.com");
		
		navigate.back();
		navigate.forward();
		
		navigate.visit("example4.com");
		
		navigate.forward();
		
	}
	

}
