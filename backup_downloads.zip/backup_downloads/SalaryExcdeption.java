package day3;

//Custom Exception
public class SalaryExcdeption extends Exception {

	public SalaryExcdeption() {
		super();
		
	}

	public SalaryExcdeption(String message) {
		super(message);
		
	}
	

}
