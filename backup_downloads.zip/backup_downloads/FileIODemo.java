package day3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileIODemo {
	
	public static void main(String[] args)  {
	
//		try {
//			FileWriter fw=new FileWriter("abc.txt");
//			fw.append("Hello ");
//			fw.flush();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		
		try {
			FileReader fr=new FileReader("abc.txt");
			BufferedReader br=new BufferedReader(fr);
			int c=(char)br.read();
			while(c!=-1)
			{
				System.out.print((char)c);
				c=br.read();
			
			}
			//String str=br.readLine();
			//System.out.println(str);
			}
			catch(Exception e)
			{
				
			}
	
			
			File file=new File("abc.txt");
			
			System.out.println("Length :"+file.length());
			
		
	}

}
