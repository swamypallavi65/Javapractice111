package demo.day1Api;

import static io.restassured.RestAssured.given;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class APIUITest {

	private int id ;
	
	@Test(priority=1)
	public void createUser() {
		User user = new User();
		user.setUid(101);
		user.setUname("Manisha");
		user.setContact("123457888");

		Response res  = given().contentType(ContentType.JSON)
								.body(user)
				.when()
				              .post("https://jsonplaceholder.typicode.com/users")
				 .then()
				               .statusCode(201)
				               .extract()
				               .response();
		
		
		      System.out.println(res.asString());
		      id=res.jsonPath().getInt("uid");

		   
	}
	
	
	@Test(priority=2)
	public void userTest()
	{
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://jsonplaceholder.typicode.com/users/"+id);
		
		WebElement  element=driver.findElement(By.id("username"));
		
		Assert.assertEquals(element.getText(), "Manisha");  
	}

}
