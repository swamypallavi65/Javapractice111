package day4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import day3.Employee;

public class EmployeeSet {
	
	public static void main(String[]Args)
	{
		List<Employee> empList=new ArrayList<>();
		
		Employee emp1=new Employee("Asha",50000);
		Employee emp2=new Employee("Pawan",100000);
		Employee emp3=new Employee("Neeta",90000);
		Employee emp4=new Employee("Anju",80000);
		
		empList.add(emp4);
		empList.add(emp2);
		empList.add(emp3);
		empList.add(emp1);
		
		
		Collections.sort(empList,new NameComparator());
		
		for(Employee emp:empList)
			  System.out.println(emp);
		
		//System.out.println("Employee with Highest Salary :"+empList.getLast());
		
		
	}

}
