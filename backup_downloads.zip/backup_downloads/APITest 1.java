package demo.day1Api;

import java.time.LocalTime;
import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.JsonObject;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import io.restassured.response.Response;

public class APITest {
	
	String baseUrl="https://jsonplaceholder.typicode.com";
	
	@Test
	public void getUser()
	{
				
//		Response response=RestAssured.get(baseUrl+"/posts");
//		System.out.println(response.asString());
//		Assert.assertEquals(response.statusCode(), 200);
		
		         given()
		           .when()
		               .get(baseUrl+"/posts")
		           .then()
		               .assertThat()
                       .statusCode(200)
                       .time(lessThan(197000L))
		               .log()
		               .body();
	           
	}
	
	//Create request body 1.String 2.HahMap  3.org.json
	//@Test
	public void postUser()
	{
		HashMap<String,String> reqBody=new HashMap<>();
		reqBody.put("name", "Pawan");
		reqBody.put("email","Pawan@gmail.com");
		
		JsonObject req=new JsonObject();
		req.addProperty("name", "Pawan");
		req.addProperty("email","Pawan@gmail.com");
		
		  given()
		              .header("content-type","application/json")
		             // .body("{\"name\":\"Manisha\",\"email\":\"manisha@gmail.com\"}")
		              .body(req.toString())
		            .when()
		               .post(baseUrl+"/posts")
		             .then()
		                .assertThat()
		                .statusCode(201)
		                .body("name",equalTo("Pawan"))
		                .header("Content-Type", "application/json; charset=utf-8")
		                .log()
                        .all();	
		      
		    //  res.time(); 
		    //String name=res.jsonPath().getString("name");
		 
		   // System.out.println(name);
		    //Assert.assertEquals(name, "Pawan");
		              
			//System.out.println(res.asString());
				
	}
	
	
	
	
	
	
	

}
