package day4;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeMap;

public class MapDemp {

	public static void main(String[] args) {
		
		HashMap<String,Integer> hmap=new HashMap<>();
		
		hmap.put("A", 90);
		hmap.put("B", 80);
		hmap.put("D", 70);
		hmap.put("E", 60);
		hmap.put("C", 30);
	
		
//		for(Entry<String,Integer> entry:hmap.entrySet())
//		{
//			 System.out.println("Key :"+entry.getKey() +"  Value: "+entry.getValue() );
//		}
		
		hmap.entrySet().stream().
		    forEach(entry->System.out.println("Key :"+entry.getKey() +"  Value: "+entry.getValue() ));
	
		 System.out.println("TreeMap------------");
		 
		TreeMap<String,Integer> tmap=new TreeMap<>(Collections.reverseOrder());
		
		tmap.put("A", 90);
		tmap.put("B", 80);
		tmap.put("D", 70);
		tmap.put("E", 60);
		tmap.put("C", 30);
		
		
		tmap.entrySet().stream().
	         forEach(entry->System.out.println("Key :"+entry.getKey() +"  Value: "+entry.getValue()));
	         
	  // long count=tmap.entrySet().stream().filter(entry-> entry.getValue()>70).count(); 
	   
		//System.out.println("Total elements :"+count);

	}

}
