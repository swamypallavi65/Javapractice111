package demo.day1Api;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class ReportDemo {
	
	ExtentSparkReporter spark;
	ExtentReports reports;
	ExtentTest test;
	
	
	@BeforeClass
	public void setUp()
	{
		spark=new ExtentSparkReporter("test-output/report1.html");
		reports=new ExtentReports();
		reports.attachReporter(spark);
	}
	
	@Test
	public void getUserTest()
	{
		RestAssured.baseURI="https://jsonplaceholder.typicode.com";
		test=reports.createTest("getapi-test");
		test.log(Status.INFO, "get api test start");
		
		RestAssured.baseURI="https://jsonplaceholder.typicode.com";
		    given()
		    .when()
		           .get("/users/1")
			 .then()
				   .statusCode(200);
		         
		test.log(Status.PASS,"Test Passed successfyully");
		reports.flush();
		
	
	}
	
	
	@Test
	public void createUserTest()
	{
		RestAssured.baseURI="https://jsonplaceholder.typicode.com";
		test=reports.createTest("postapi-test");
		
		test.log(Status.INFO, "post api test start");
		
		User user=new User();
	     user.setUid(101);
	     user.setUname("Manisha");
	     user.setContact("123457888");
		
		    given()
		      .contentType(ContentType.JSON)
		      .body(user)
		    .when()
		           .post("/users")
			 .then()
				   .statusCode(201);
		         
		test.log(Status.PASS,"User created successfyully");
		reports.flush();
		
	
	}
	
	
	

}
