package demo.day1Api;


import static io.restassured.RestAssured.*;

import java.util.concurrent.ConcurrentHashMap;

import  org.hamcrest.Matchers;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class SerDeserDemo {
	
	@Test(priority=1)
	public void serializeUserTest()
	{
		//User user=new User(101,"Manisha","123456789");
		
		     User user=new User();
		     user.setUid(101);
		     user.setUname("Manisha");
		     user.setContact("123457888");
		
		Response res=given()
		     .contentType(ContentType.JSON)
		     //Serialization
             .body(user)
        .when() 
            .post("https://jsonplaceholder.typicode.com/users")
        .then()   
           .extract()
           .response();
		
		
		
		//Deserialiazation
		Gson gson=new Gson();
		User user1=gson.fromJson(res.asString(), User.class);
		
		  System.out.println("Id :"+user1.getUid());
		  System.out.println("Name :"+user1.getUname());
		  System.out.println("Contact :"+user1.getContact());
		  
		
	}
	
	
}
