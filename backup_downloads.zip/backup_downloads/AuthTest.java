package demo.day1Api;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import  static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

public class AuthTest {
	
	//@Test
	public void basicAuth()
	{
	    given()
	       .auth()
	       .basic("postman", "password")
	       .log()
	       .all()
	    .when()
	       .get("https://postman-echo.com/basic-auth")
		.then()
		   .statusCode(200)
		    .body("authenticated",equalTo(true))
		    .log().all();
		 
	}
	
	//  @Test
	  public void apiAuth()
	  {
		     User user=new User();
		     user.setUid(101);
		     user.setUname("Manisha");
		     user.setContact("123457888");
		     
		     given()
		        //.contentType(ContentType.JSON)
		        .header("Content-Type","application/json")
		        .header("x-api-key"," reqres-free-v1")
		       // .queryParam("x-api-key","reqres-free-v1")
		        .body(user) 
		        
		     .when()
		         .post("https://reqres.in/api/users")  
		     .then()
		        .statusCode(201)
		        .log()
		         .body();
	  }
	  
	 // @Test
	  public void tokenAuth()
	  {
		  String token="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";
		  		
		 given()
		   .header("authorization","Bearer "+token)
		  .when()
		     .get("https://api.github.com/user/repos")
		   .then()
              .statusCode(200)
              .log()
              .body();	   
		  
	  }
	  
	  @Test
	  
	  
	  //1.get the token by sending post request
	  //2.send the req with token
	  public void oAuthTest()
	  {
		  
		 String token=  given()
		    .formParam("client_id", "abc")
		    .formParam("client_secret", "xyz")
		    .formParam("grant_type", "authorizationcode")
		    
		   .when()  
		     .post("ürl")
		  .then()
		      .statusCode(201)
		      .extract()
		      .jsonPath()
		      .getString("access_token");
//		 
		 
		 given()
		   .auth()
		   .oauth2(token)
		  .when() 
		     .get("url")
		   .then()
		      .statusCode(200)
		      .log()
		      .body();
		  
	  }
	  


}
