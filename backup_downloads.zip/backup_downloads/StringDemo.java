package day3;

public class StringDemo {

	public static void main(String[] args) {
		
		String name="Manisha";
		 
//		name=name.concat(" Agrawal"); 
//		
//		String name1="Manisha";
//		
//		String name2=new String("Manisha");
//		
//		//System.out.println(name);
//		
//		
//		StringBuilder sb=new StringBuilder(name1);
//		
//		sb.append(" Agrawal");
//		
//		System.out.println(sb);
//		
//		sb.reverse();
//		System.out.println(sb);
//		
//		
//       StringBuffer sbf=new StringBuffer(name1);
//		
//		sbf.append(" Agrawal");
//		
//		//System.out.println(sbf);
//		
		String revName="";
		for(int i=name.length()-1;i>=0;i--)
		{
			revName=revName+name.charAt(i);
		}
		
		System.out.println(revName);

	}

}
