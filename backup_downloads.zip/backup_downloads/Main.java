package day3;

public class Main {

	public static void main(String[] args)  {
		
		Employee emp=new Employee();
		emp.setName("Manisha");
		try {
		emp.setSalary(3000);
		}
		catch(SalaryExcdeption se)
		{
			System.out.println(se.getMessage());
		}
	}

}
