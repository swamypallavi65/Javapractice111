package restassured.restassureddemo2;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import  static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;

public class RestAssuredTest {

	@BeforeClass
	public void setUp() {
		baseURI = "https://jsonplaceholder.typicode.com/users";
	}

	// @Test
	public void getUser() {
		 Response response= get("/1")
				         .then()
				           .assertThat()
				            .statusCode(200)
				            .extract()
				            .response();
		   System.out.println(response.asString());
		 
	}

	//
	
	@Test
	public void postUser() {
		//String reqBody = "{\"name\":\"Manisha\",\"email\" :\"manisha@gmail.com\"}";
		
//		HashMap<String,String> reqBody=new HashMap<>();
//		     reqBody.put("name", "Manisha");
//		     reqBody.put("email","manisha@gmail.com");

		
//		   JsonObject reqBody=new JsonObject();
//		   
//		   reqBody.addProperty("name","Manisha");
//		   reqBody.addProperty("email","manisha@gmail.com");
//		   
		
		    User user=new User();
		      user.setName("Manisha");
		      user.setEmail("manisha@gmail.com");
		      
				Response response=	given()
								//.contentType(ContentType.JSON)
							    .header("Content-Type","application/json")
								.body(user)
								.when()
								  .post()
						       .then()
						       .statusCode(201)
						       .body("name", equalTo("Manisha"))
						       .extract()
						       .response();
			//	System.out.println(response.asString());
				
				//Deserialization
				
//				Gson gson=new Gson();
//				User user1=gson.fromJson(response.asString(),User.class);
//				System.out.println(user1);
//				
				
			//	To extract data from response 
				
				String name=response.jsonPath().getString("name");
				int id=response.jsonPath().getInt("id");
				
				System.out.println("Name :"+name);
				System.out.println("Id :"+id);
		
	}

	// @Test
	public void putUser() {
		String reqBody = "{\"name\":\"Manisha\",\"email\" :\"manisha@gmail.com\"}";

		Response response = given().contentType(ContentType.JSON).body(reqBody)
				// .when()
				.put("/1");
		System.out.println(response.asString());

	}

	//@Test
	public void deleteUser() {
		Response response = delete("/1");
		Assert.assertEquals(response.statusCode(), 200);

	}

}
