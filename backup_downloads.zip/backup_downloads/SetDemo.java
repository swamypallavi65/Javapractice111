package day4;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		
		HashSet<Integer> hset=new HashSet<>();
	
		hset.add(30);
		hset.add(4);
		hset.add(80);
		hset.add(30);
		
		for(int i:hset)
			System.out.println("HashSet :"+i);
		
		LinkedHashSet<Integer> lset=new LinkedHashSet<Integer>();
		lset.add(30);
		lset.add(4);
		lset.add(80);
				
		for(int i:lset)
			System.out.println("LinkedHashSet :"+i);
		
		
		TreeSet<Integer> tset=new TreeSet<>(lset);
		for(int i:tset)
			System.out.println("TreeSet :"+i);
		
		
		

	}

}
