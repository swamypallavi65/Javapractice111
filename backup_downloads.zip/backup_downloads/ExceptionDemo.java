package day3;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionDemo {
	
	
	public static void main(String[] args)
	{
		Scanner scanner=new Scanner(System.in);
		
		try {
			FileReader fr=new FileReader("abc.txt");
		int n1,n2;
		
		System.out.println("Enter number 1:");
		n1=scanner.nextInt();
		System.out.println("Enter number 2:");
		n2=scanner.nextInt();
		System.out.println(n1/n2);
		}
	
		catch(ArithmeticException ae)
		{
			System.out.println("A number can't be divide by zero");
		}
		catch(InputMismatchException ie)
		{
			System.out.println("Invalid input.PLease enter number only");
		}
		catch(FileNotFoundException fe)
		{
			System.out.println("File abc.txt does not exist");
		}
		catch(Exception e)
		{
		   System.out.println("Exception e");	
		}
		
		finally {
			
			System.out.println("finally executed");
			scanner.close();
		}
		
		
	}

}
