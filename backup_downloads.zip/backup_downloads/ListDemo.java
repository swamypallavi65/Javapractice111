package day4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import demo.Employee;

public class ListDemo {
	
	
	public static void main(String [] args)
	{
		ArrayList<String> fruits=new ArrayList<>();
		
		fruits.add("Apple");
		fruits.add("Mango");
		fruits.add("Pear");
		fruits.add("Orange");
		fruits.add("Orange");
		
		Collections.sort(fruits);
		
		// ways to iterate over collection
		
//		for (int i = 0; i < fruits.size(); i++) {
//			System.out.println(fruits.get(i));
//		}
		
		//for-each loop
		
//		for(String fruit:fruits)
//			System.out.println(fruit);
		
		
		//using iterator
		
//		Iterator<String> itr=fruits.iterator();
//		
//		while(itr.hasNext())
//			System.out.println(itr.next());
		
		
		//Stream 
		fruits.stream().forEach(fruit->System.out.println(fruit));
		
		
	}

}
