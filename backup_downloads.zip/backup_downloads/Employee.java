package day3;

public class Employee {
	
	private String name;
	private int salary;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Employee(String name, int salary) {
		super();
		this.name = name;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) throws SalaryExcdeption {
		//try {
	 	if(salary<10000)
			throw new SalaryExcdeption("Salary can't be lesser than 10000");
		this.salary = salary;
		//}catch(SalaryExcdeption se)
		//{
			//System.out.println(se.getMessage());
	//	}
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + "]";
	}
	
	

}
