package demo.day1Api;

import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class APITest {
	
	String baseUrl="https://jsonplaceholder.typicode.com";
	
	@Test
	public void getUser()
	{
				
//		Response response=RestAssured.get(baseUrl+"/posts");
//		System.out.println(response.asString());
//		Assert.assertEquals(response.statusCode(), 200);
		
		RestAssured.given()
		           .when()
		               .get(baseUrl+"/posts/1")
		           .then()
		               .assertThat()
                       .statusCode(200)
		               .log()
		               .body();
	           
	}
	
	//@Test
	public void postUser()
	{
		HashMap<String,String> reqBody=new HashMap<>();
		reqBody.put("name", "Pawan");
		reqBody.put("email","Pawan@gmail.com");
		
		RestAssured.given()
		              .header("content-type","application/json")
		              .body(reqBody)
		              
		            .when()
		               .post(baseUrl+"/posts")
		             .then()
		                .assertThat()
		                .statusCode(201)
		                .log()
		                .all();
		
		//System.out.println(res.asString());
				
	}
	
	
	
	
	

}
