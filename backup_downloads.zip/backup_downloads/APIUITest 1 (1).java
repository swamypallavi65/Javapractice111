package restassured.restassureddemo2;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class APIUITest {
	
	private int id;
	
	@Test
	public void createUser()
	{
		baseURI="https://jsonplaceholder.typicode.com/users";
		String reqBody = "{\"name\":\"Manisha\",\"email\" :\"manisha@gmail.com\"}";
		id=given()
		   .contentType(ContentType.JSON)
	       .body(reqBody)
	    .when()   
	       .post()
	    .then()
	       .statusCode(201)
	       .body(matchesJsonSchemaInClasspath("user_schema.json"))
	       .log()
	       .body().extract().jsonPath().getInt("id");
		
	       
	}
	
	@Test(dependsOnMethods = "createUser")
	public void testUser()
	{
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://jsonplaceholder.typicode.com/users/"+id);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		WebElement userName=driver.findElement(By.id("username"));
		
		Assert.assertEquals(userName.getText(),"Manisha");
		
		
	}

}
