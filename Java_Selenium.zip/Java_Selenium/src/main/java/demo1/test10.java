package demo1;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//Verify Subscription in home page
public class test10 {
	
	public static WebDriver driver;
	public static WebElement element;

	public static void main(String[] args) throws InterruptedException {
		
		 driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();

		boolean logo = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();

		if(logo==true)
		{
		System.out.println("Home page is displayed");
		}
		else{
		System.out.println("Home page is not displayed");
	}
		
		//verify sub
		WebElement sub=driver.findElement(By.xpath("//*[text()='Subscription']"));
		System.out.println("sub text:"+sub.getText());

		JavascriptExecutor j = (JavascriptExecutor) driver;
		//To scroll down
		j.executeScript("window.scrollBy(0,500)");
		driver.findElement(By.xpath("//*[text()='Subscription']")).getText();
		WebElement email=driver.findElement(By.id("susbscribe_email"));
		email.sendKeys("abccba@gmail.com");
	
		driver.findElement(By.id("subscribe")).click();
		
		boolean subMsg = driver.findElement(By.xpath("//*[text()='You have been successfully subscribed!']")).isDisplayed();
	
		if(subMsg=true) {
			System.out.println("sub msg displayed");
		}
		else {
			System.out.println("sub msg not displayed");
		}
		WebElement submsg1 = driver.findElement(By.xpath("//*[text()='You have been successfully subscribed!']"));
		System.out.println("sub msg:"+submsg1.getText());
	}
	

}
