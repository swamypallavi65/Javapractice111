package demo1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

//: Verify All Products and product detail page
public class test8 {
	
	public static WebDriver driver;
	public static WebElement element;

	public static void main(String[] args) throws InterruptedException {
		
		 driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();

		boolean logo = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();

		if(logo==true)
		{
		System.out.println("Home page is displayed");
		}
		else{
		System.out.println("Home page is not displayed");
	}
		driver.findElement(By.xpath("//*[@href='/products'][text()=' Products']")).click();
		boolean prod = driver.findElement(By.xpath("//*[@class='title text-center'][text()='All Products']")).isDisplayed();

		if(prod==true)
		{
		System.out.println("Product page is displayed");
		}
		else{
		System.out.println("product page is not displayed");
	}
//		WebElement prodct = driver.findElement(By.xpath("//*[@class='title text-center']//*[text()='Test Cases']"));
//		System.out.println("testcase text:"+prodct.getText());

				//view product
				WebElement viewproduct=driver.findElement(By.xpath("//a[@href='/product_details/1'][text()='View Product']"));
				viewproduct.click();
				
				//Verify that product detail is visible: product name, category, price, availability, condition, brand
				WebElement productdetails=driver.findElement(By.xpath("//div[@class='product-information']"));
				if(productdetails.isDisplayed())
				{
					System.out.println("productdetails is displayed");
				}
				else {
					System.out.println("productdetails is not displayed");
				}
				
		//Verify that detail detail is visible: product name, category, price, availability, condition, brand

				 // Verify product name
				        WebElement productName = driver.findElement(By.xpath("//div[@class='product-information']/h2"));
				        System.out.println("Product Name: " + productName.getText());

				        // Verify category
				        WebElement category = driver.findElement(By.xpath("//div[@class='product-information']/p[1]"));
				        System.out.println("Category: " + category.getText());

				        // Verify price
				        WebElement price = driver.findElement(By.xpath("//div[@class='product-information']/span/span"));
				        System.out.println("Price: " + price.getText());
				        

				        // Verify availability
				              WebElement availability = driver.findElement(By.xpath("//div[@class='product-information']/p[2]"));
				              System.out.println("Availability: " + availability.getText());

				              // Verify condition
				              WebElement condition = driver.findElement(By.xpath("//div[@class='product-information']/p[3]"));
				              System.out.println("Condition: " + condition.getText());

				              // Verify brand
				              WebElement brand = driver.findElement(By.xpath("//div[@class='product-information']/p[4]"));
				              System.out.println("Brand: " + brand.getText());

	}
}
