package demo1;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class test1 {

	
	public static void main(String[] args) throws InterruptedException {
		//Place Order: Register while Checkout
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\p300\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		boolean logo = driver.findElement(By.xpath("//img[@alt='Website for automation practice']")).isDisplayed();
		if(logo==true)
		{
		System.out.println("Home page is displayed");
		}
		else{
		System.out.println("Home page is not displayed");
	}
		driver.findElement(By.xpath("//*[@href='/products'][text()=' Products']")).click();
		driver.findElement(By.xpath("//*[@class=\"brands_products\"]")).isDisplayed();
		driver.findElement(By.xpath("//*[@href='/product_details/1'][text()='View Product']")).click();		
 
// add to cart
		driver.findElement(By.xpath("//*[@class='btn btn-default cart']")).click();
		//driver.findElement(By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")).click();
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		WebElement viewcart = wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[text()='View Cart']"))));
		viewcart.click();
		WebElement checkOutpg = driver.findElement(By.xpath("//*[@class=\"active\"]"));
		System.out.println("check out page display:"+checkOutpg.getText());
		//check out
		driver.findElement(By.xpath("//*[@class=\"btn btn-default check_out\"]")).click();
		WebElement regLogin = wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[text()='Register / Login']"))));
		regLogin.click();
//'Signup / Login' 
		WebElement newUser_Signup =driver.findElement(By.xpath("//*[@href='/login'][text()=' Signup / Login']"));
		newUser_Signup.click();
			boolean signUpVis = driver.findElement(By.xpath("//*[@href='/login'][text()=' Signup / Login']")).isDisplayed();
			if(signUpVis==true)
			{
			System.out.println("signUp is displayed");
			}
			else{
			System.out.println("signUpVis is not displayed");
			}
		//New user information
			driver.findElement(By.name("name")).sendKeys("PallaviS");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@data-qa='signup-email']")).sendKeys("abc0718abc@gmail.com");
			driver.findElement(By.xpath("//button[@class='btn btn-default'][text()='Signup']")).click();
			WebElement createAct = driver.findElement(By.xpath("//h2[@class ='title text-center']//*[text()='Enter Account Information']"));
			System.out.println("createAct message:" + createAct.getText());
			//filling all details
			driver.findElement(By.id("id_gender2")).click();
			driver.findElement(By.id("password")).sendKeys("abcabc@123");
			driver.findElement(By.xpath("//*[@id=\"days\"]/option[2]")).click();
			driver.findElement(By.xpath("//*[@id=\"months\"]/option[2]")).click();
			driver.findElement(By.xpath("//*[@id=\"years\"]/option[2]")).click();
			driver.findElement(By.id("newsletter")).click();
			driver.findElement(By.id("optin")).click();
			Map<String,String> accountD = new HashMap<>();
			accountD.put("first_name","Pallavi");
			accountD.put("last_name","Swamy");
			accountD.put("company","Capgemini");
			accountD.put("address1","Capgemini Office1");
			accountD.put("address1","Capgemini Office2");
			accountD.put("state","Maharashtra");
			accountD.put("city","Pune");
			accountD.put("zipcode","123456");
			accountD.put("mobile_number","1234567890");
			for(Map.Entry<String, String> entry: accountD.entrySet()) {
				try {
					WebElement data = driver.findElement(By.id(entry.getKey()));
					data.clear();
					data.sendKeys(entry.getValue());
				}catch(Exception e) {
					System.out.println("data not found: " +entry.getKey());
				}
			}
			driver.findElement(By.xpath("//*[@data-qa='create-account']")).click();
			boolean accCreated = driver.findElement(By.xpath("//*[@class='title text-center']//*[text()='Account Created!']")).isDisplayed();
			if(accCreated==true)
			{
			System.out.println("accCreated is displayed");
			}
			else{
			System.out.println("accCreated is not displayed");
			}

			driver.findElement(By.xpath("//*[@data-qa=\"continue-button\"]")).click();
			//loggedin as username

			boolean accUserName = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")).isDisplayed();
			if(accUserName==true)
			{
			System.out.println("accUserName  is displayed");
			}
			else{
			System.out.println("accUserName  is not displayed");
			}

			driver.findElement(By.xpath("//*[@href='/view_cart'][text()=' Cart']")).click();
			WebElement checkOutpg1 = driver.findElement(By.xpath("//*[@class=\"active\"]"));
			System.out.println("check out page display:"+checkOutpg1.getText());
 
			//check out
			driver.findElement(By.xpath("//*[@class=\"btn btn-default check_out\"]")).click();
			// Address verification 

			WebElement addVerify = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("address_delivery")));
			//addVerify.click();
		String actualAdd = addVerify.getText().trim();
		System.out.println("Actual address on page:" + actualAdd);
		//String expectedAddress = "Mrs. Pallavi Swamy,Capgemini,Capgemini Office2,Pune Maharashtra 123456,India,1234567890";

		String expectedAddress ="Mrs. Pallavi Swamy,Capgemini,Capgemini Office2,Pune Maharashtra 123456,India,1234567890";
		if(actualAdd.equals(expectedAddress)) {
			System.out.println("Address verified.");
		}
		else {
			System.out.println("Address not verified");
			System.out.println("expected Address:"+expectedAddress);
			System.out.println("actualAdd:"+actualAdd);
		}
		// place order 
		driver.findElement(By.xpath("//*[@class=\"form-control\"]")).sendKeys("Product place order");
		driver.findElement(By.xpath("//*[@class='btn btn-default check_out']")).click();
		driver.findElement(By.name("name_on_card")).sendKeys("Pallavi");
		driver.findElement(By.name("card_number")).sendKeys("Swamy");
		driver.findElement(By.name("cvc")).sendKeys("Capgemini");
		driver.findElement(By.name("expiry_month")).sendKeys("06");
		driver.findElement(By.name("expiry_year")).sendKeys("5000");
		driver.findElement(By.xpath("//*[@class=\"form-control btn btn-primary submit-button\"]")).click();
		//*[@id="form"]/div/div/div/p
		WebElement prodConfirm = driver.findElement(By.xpath("//*[text()='Congratulations! Your order has been confirmed!']"));
		System.out.println("prodConfirm:" + prodConfirm.getText());
		//delete account
		driver.findElement(By.xpath("//*[@href='/delete_account'][text()=' Delete Account']")).click();
		WebElement accDel = driver.findElement(By.xpath("//*[@class='title text-center']"));
		System.out.println("Account Delete message:" + accDel.getText());

		driver.findElement(By.xpath("//*[@data-qa=\"continue-button\"]")).click();
	}
 

}
