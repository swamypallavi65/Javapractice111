package demo1;

public class str_StrBuf {

	public static void main(String[] args) {
	
		        // String example (immutable)
//		        String str = "Hello";
//		        str.concat(" World");
//		        System.out.println("String result: " + str); 
//		        // StringBuffer example (mutable)
//		        StringBuffer sb = new StringBuffer("Hello");
//		        sb.append(" World");
//		        System.out.println("StringBuffer result: " + sb); 
		
				String a="Hello";
		
		        a = a.concat("World");
		        System.out.println(a);
		    


	}

}
