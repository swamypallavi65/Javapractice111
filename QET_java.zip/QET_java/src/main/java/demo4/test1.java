package demo4;

public class test1 {
	
	static int a= method1();
	

	// static method 
	static int method1() {
		System.out.println("print from method1");
        return 20;
	}

	public static void main(String[] args) {
		
		System.out.println("print a value:"+a);

	}


}
