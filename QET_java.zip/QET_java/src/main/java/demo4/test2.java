package demo4;

import java.util.Scanner;

public class test2 {

	public static void main(String[] args) {

		System.out.println("Add number of row");
		Scanner sc = new Scanner(System.in);
	
		int row = sc.nextInt();
		
//		
//		for(int i=0;i<4;i++) {
//	
//			for(int j=0;j<4-i;j++) {
//				//System.out.print( k);
//				System.out.print("\t");// help in spacing
//				//k++;
//			}
//			System.out.println( "");// print next line
//		}
		

	}

}
