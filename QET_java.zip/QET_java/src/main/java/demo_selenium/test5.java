package demo_selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test5 {

	public static void main(String[] args) throws InterruptedException {
		
	      WebDriver driver = new ChromeDriver();
	        String url = "https://selenium08.blogspot.com/2019/07/check-box- and-radio-buttons.html";

	            driver.get(url);
	            driver.manage().window().maximize();
	            Thread.sleep(1000);

	}

}
