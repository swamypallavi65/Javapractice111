package demo_selenium;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class test3 {

	 static WebDriver driver ;
	public static void main(String[] args) throws InterruptedException {
	
	    driver = new ChromeDriver();
        String url = "http://demo.automationtesting.in/Register.html";

            driver.get(url);
            driver.manage().window().maximize();
            Thread.sleep(1000);
            //Automate the entire Registration Page and Submit the form
//            
//            Map<String, String> regD = new HashMap<>();// printing not in seq
            Map<String, String> regD = new LinkedHashMap();
            regD.put("xpath=//*[@id='basicBootstrapForm']//*[@placeholder='First Name']", "Pallavi");
            regD.put("xpath=//*[@placeholder='Last Name']", "Swamy");
            regD.put("xpath=//*[@id='basicBootstrapForm']//*[@ng-model='Adress']", "Capgemini,India");
            regD.put("xpath=//*[@id='eid']//*[@ng-model='EmailAdress']", "abc123@gmail.com");
            regD.put("xpath=//*[@ng-model='Phone']", "1234567890");
           regD.put("xpath=//*[@value='FeMale']/parent::label", "");
           regD.put("xpath=//*[@id='checkbox1']/parent::div", "");
         //  regD.put("xpath=//div[contains(@class,'ui-autocomplete')]//li[text()='Arabic']", "");
           regD.put("xpath=//*[@id='firstpassword']", "password@123");
           regD.put("xpath=//*[@id='secondpassword']", "password@123");
           
            
            //
            for(Map.Entry<String, String> entry: regD.entrySet()) {
            	
            	String key = entry.getKey();// ex: id=username
            	String[] parts = key.split("=",2);// Split into ["id", "username"]
            	String locatorType = parts[0].trim();
            	String locatorValue = parts[1].trim();
            	String inputValue = entry.getValue();
            	
            	WebElement element = null;
            	
            	try {
            		switch (locatorType.toLowerCase()) {
					case "id":
						element=driver.findElement(By.id(locatorValue));
						break;

					case "xpath":
						element= driver.findElement(By.xpath(locatorValue));
						break;
						
					case "css":
						element = driver.findElement(By.xpath(locatorValue));
						break;
						
					default:
						
					throw new IllegalArgumentException("Unsupported locator type: " + locatorType);
            		}

					
            		if(!inputValue.isEmpty()) {
            			element.clear();
            			element.sendKeys(inputValue);
            			System.out.println("print reg value:"+inputValue);
            			
            		}else {
            			element.click();
            		}
            	}
					
				catch (Exception e) {
					 System.out.println("Element not found or error for: " + locatorType );
					
				}
            }
            //selecting dropdown values on reg form
            Map<String, String> dropdownD = new LinkedHashMap();
            dropdownD.put("xpath=//*[@id='msdd']", "Arabic");

			dropdownD.put("xpath=//*[@id='Skills']", "Adobe InDesign");
			dropdownD.put("xpath=//*[@id='countries']", "India"); // Country*
			dropdownD.put("xpath=//*[@id='country']", "Australia"); // Select Country
			dropdownD.put("xpath=//*[@id='yearbox']", "2025"); //year
			dropdownD.put("xpath=//*[@placeholder='Month']", "May"); //  Month
			dropdownD.put("xpath=//*[@id='daybox']", "15"); // day
			//dropdownD.put("xpath=//*[@id='submitbtn']", "");

           
            for (Map.Entry<String, String> entry : dropdownD.entrySet()) {
                String key = entry.getKey();
                String[] parts = key.split("=", 2);
                String locatorType = parts[0].trim();
                String locatorValue = parts[1].trim();
                String valueToSelect = entry.getValue();

                WebElement dropdownElement = null;

                try {
                    switch (locatorType.toLowerCase()) {
                        case "id":
                            dropdownElement = driver.findElement(By.id(locatorValue));
                            break;
                        case "xpath":
                            dropdownElement = driver.findElement(By.xpath(locatorValue));
                            break;
                        case "css":
                            dropdownElement = driver.findElement(By.cssSelector(locatorValue));
                            break;
                        default:
                            throw new IllegalArgumentException("Unsupported locator type: " + locatorType);
                    }

                    if (dropdownElement.getTagName().equalsIgnoreCase("select")) {
                    Select select = new Select(dropdownElement);
                    select.selectByVisibleText(valueToSelect);
                    System.out.println("Selected from dropdown: " + valueToSelect);
                    }
                } catch (Exception e) {
                    System.out.println("Error selecting from dropdown: " + locatorType);
                }
            }
            driver.findElement(By.id("submitbtn")).click();
          //  driver.quit();

	}

}
